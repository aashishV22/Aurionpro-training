package com.aurionpro.model;

public interface ICoach {
	String getTrainingPlan();
	String getDietPlain();
}

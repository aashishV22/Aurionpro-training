package com.aurionpro.model;

import org.springframework.stereotype.Component;

@Component
public class WeightLossDiet implements IDiet {

	@Override
	public String getPlan() {
		// TODO Auto-generated method stub
		return "This is weight loss Diet class";
	}

}
